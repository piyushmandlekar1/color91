
function predictColor() {
    const colors = ["Red", "Green", "Blue"];
    const choice = colors[Math.floor(Math.random() * colors.length)];
    alert("Predicted color: " + choice);
}
